<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_list_bills extends Model
{
    protected $table = 'list_bill';
    public $timestamps = false;
}
