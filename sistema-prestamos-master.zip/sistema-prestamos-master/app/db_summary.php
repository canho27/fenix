<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_summary extends Model
{
    protected $table = 'summary';
}
